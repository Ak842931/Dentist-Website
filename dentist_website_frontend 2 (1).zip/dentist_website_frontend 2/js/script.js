let menu = document.querySelector('#menu-btn');
let navbar = document.querySelector('.header .nav');
let header = document.querySelector('.header');

menu.onclick = () =>{
   menu.classList.toggle('fa-times');
   navbar.classList.toggle('active');
}

window.onscroll = () =>{
   menu.classList.remove('fa-times');
   navbar.classList.remove('active');

  if(window.scrollY > 0){
     header.classList.add('active');
  }else{
     header.classList.remove('active');
  }

}

<script>
function gotowhatsapp() {
    
    var service = document.getElementById("To Make Appoinment").value;
    var name = document.getElementById("name").value;
    var phone = document.getElementById("phone").value;
    var email = document.getElementById("email").value;
    var Gender = document.getElementById("Gender").value;
    var phone = document.getElementById("Date").value;

    var url = "https://wa.me/919004006811?text=" 
    + "To make Appoinment: " + service + "%0a"
    + "Name: " + name + "%0a"
    + "Phone: " + phone + "%0a"
    + "Date And Time: " + email + "%0a"
    + "Gender: " + Gender + "%0a"
    + "Date: " + phone +"%0a";

    window.open(url, '_blank').focus();
}
</script>
// Get the form element
const feedbackForm = document.getElementById('feedback-form');

feedbackForm.addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent the default form submission

    // Fetch user input values
    const name = document.getElementById('name').value;
    const email = document.getElementById('email').value;
    const message = document.getElementById('message').value;

    // You can add custom validation logic here

    // If the validation passes, you can send the data to a server or perform any other action
    // For demonstration purposes, we'll log the data to the console
    console.log('Name: ' + name);
    console.log('Email: ' + email);
    console.log('Feedback: ' + message);

    // Optionally, you can display a confirmation message to the user
    alert('Feedback submitted successfully!');

    // Reset the form
    feedbackForm.reset();
});
<script>
function gotowhatsapp() {
    
    var name = document.getElementById("name").value;
    var phone = document.getElementById("phone").value;
    var email = document.getElementById("email").value;
    var service = document.getElementById("service").value;

    var url = "https://wa.me/919004006811?text=" 
    + "Name: " + name + "%0a"
    + "Phone: " + phone + "%0a"
    + "Email: " + email  + "%0a"
    + "Service: " + service; 

    window.open(url, '_blank').focus();
}
</script>
